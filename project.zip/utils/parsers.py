import re

# Приводит телефон к виду +7XXXXXXXXXX
def normalize_phone(raw: str) -> str | None:
    digits = re.sub(r"\D", "", raw)
    if len(digits) == 11 and digits[0] == "8":
        digits = "7" + digits[1:]
    elif len(digits) == 10:
        digits = "7" + digits
    return "+" + digits if 11 <= len(digits) <= 15 else None


# Проверяет ввод поля
def parse_field(field: str, text: str | None) -> tuple[str | None, str]:
    text = (text or "").strip()
    if field == "phone":
        phone = normalize_phone(text)
        return (phone, "") if phone else (None, "Введите номер в формате +7ХХХХХХХХХХ")
    if not text:
        return None, "🤖 Отправьте боту текст."
    if len(text) > 512:
        return None, "Максимум 512 символов"
    return text, ""

def md(value) -> str:
    MD_SPECIAL = "*_~+`[]^#>"
    text = str(value) if value else "—"
    for ch in MD_SPECIAL:
        text = text.replace(ch, "")
    return text or "—"